// Help instructions for binary relational calculator

void help();
