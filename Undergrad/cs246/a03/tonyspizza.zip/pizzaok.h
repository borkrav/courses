#ifndef PIZZA_OK
#define PIZZA_OK

bool pizzaok(char *input, int sizes, int basicSize);
bool pizzaok(int *input, int sizes, int basicSize);

#endif